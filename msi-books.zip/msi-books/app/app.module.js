// Define the `bookcatApp` module
angular.module('bookcatApp', ['ngRoute', 'bookList', 'bookDetail', 'core']);
