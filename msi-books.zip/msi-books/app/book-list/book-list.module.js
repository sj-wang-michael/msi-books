'use strict';

// Define the 'bookList' module
angular.module('bookList', ['core.book']);
