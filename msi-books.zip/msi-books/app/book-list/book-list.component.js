'use strict';

// Define 'phoneList' component, along with its associated template and controller
angular.
	module('bookList').
		component('bookList', { // this name is what AngularJS uses to match to the '<book-list>' element in HTML.
			templateUrl: 'book-list/book-list.template.html',
			controller: ['Book',
				function BookListController(Book) {
					this.books = Book.query();
					this.remove = function(name) {
						var index = -1;		
						for( var i = 0; i < this.books.length; i++ ) {
							if( this.books[i].name === name ) {
								index = i;
								break;
							}
						}
						if( index === -1 ) {
							alert( "Something gone wrong" );
						}
						this.books.splice( index, 1 );		
					}
					this.edit = function(name) {
					}
				}
			]
		});
		