angular.module('core.book').
	factory('Book', ['$resource', 
		function($resource) {
			return $resource('books/:bookId.json', {}, {
//			return $resource('books/books.json', {}, {
				query: {
					method: 'GET',
					params: {bookId: 'books'},
					isArray: true
				},
				update: {
					method: 'PUT',
					params: {bookId: 'books'}
		
				}
			});
		}
	]);