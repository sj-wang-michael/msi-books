angular.
	module('bookDetail').
		component('bookDetail', {
			templateUrl: 'book-detail/book-detail.template.html',
			controller: ['Book', '$routeParams', function BookDetailController(Book, $routeParams) {
					var self = this;
					
					self.book = Book.get({bookId: $routeParams.bookId}, function(book) {
						self.setName(book.name);
					});
	
					self.onSave = function onSave() {
						Book.update();
					};
					
					self.onBack = function onBack() {
						window.history.back();
					};
				}
			]
		});
	