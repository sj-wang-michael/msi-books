angular.module('bookDetail', ['ngRoute', 'core.book']);
